from unittest import TestCase
from mmeds import summary
import mmeds.config as fig


class DatabaseTests(TestCase):
    """ Tests of top-level functions """

    @classmethod
    def setUpClass(self):
        """
        Load data that is to be used by multiple test cases
        """
        pass

    @classmethod
    def tearDownClass(self):
        pass
